<?= $this->extend('layout/backend') ?>;

<?= $this->section('content') ?>;

<section class="section">
    <div class="section-header">
        <h1>Pencairan Bidang Pidana Umum</h1>
    </div>

    <div class="section-body">
        <div class="card">
            <h4 class="text text-center mt-3">-- Pilih Proses --</h4>
            <div class="card-body p-4">

            </div>
        </div>
    </div>

</section>

<?= $this->endSection() ?>;